<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\directorio;
use App\Models\contactos;

class contactosController extends Controller
{
    //
    public function VerContactos(){
        return view('vercontactos');
    }

    public function create(){
        return view('agregarcontacto');
    }

    public function store(Request $request){
        $contactos = new contactos;
        $contactos->id =1;
        $contactos->codigoEntrada=2;
        $contactos->nombre =$request->input('nombre');
        $contactos->apellido =$request->input('apellido');
        $contactos->telefono =$request->input('telefono');
        $contactos->save();
        return $this->VerContactos();
    }
}

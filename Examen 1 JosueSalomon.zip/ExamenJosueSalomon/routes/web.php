<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\directorioController;
use App\Http\Controllers\contactosController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/directorio',[directorioController::class, 'MostrarDirectorio'])->name('directorio');

Route::get('/directorio/crear',[directorioController::class, 'create'])->name('directorio.crear');

Route::post('/directorio/guardar',[directorioController::class,'store'])->name('directorio.store');

Route::get('/directorio/eliminar/{id}',[directorioController::class,'delete'])->name('directorio.delete');

Route::get('/directorio/destroy/{id}',[directorioController::class,'destroy'])->name('directorio.destroy');

Route::get('/BuscarEntrada',[directorioController::class, 'BuscarEntrada'])->name('BuscarEntrada');

Route::get('/directorio/buscar',[directorioController::class, 'BuscarDirectorio'])->name('directorio.buscar');


Route::get('/Contactos',[contactosController::class, 'VerContactos'])->name('VerContactos');

Route::get('/Contactos/crear',[contactosController::class, 'create'])->name('Contactos.crear');

Route::post('/Contactos/guardar',[contactosController::class,'store'])->name('Contactos.store');

Route::get('/Contactos/destroy/{id}',[contactosController::class,'destroy'])->name('Contactos.destroy');